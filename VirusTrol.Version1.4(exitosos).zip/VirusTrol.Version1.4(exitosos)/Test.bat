:loopstart
start
goto loopstart